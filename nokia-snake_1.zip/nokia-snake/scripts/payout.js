#!/usr/bin/env node
// Hourly leaderboard payouts.
//
//   npm run payout                               # dry run for the last finished hour
//   npm run payout -- --period 2026-09-28T14     # dry run for a specific hour (UTC)
//   npm run payout -- --auto                     # dry run for every unpaid hour in the last 24h
//   npm run payout -- --auto --execute           # what cron runs every hour — actually sends
//   npm run payout -- --claim --auto --execute   # claim StonkFun creator fees first
//
// Safety:
//  - Dry run by default. Nothing moves without --execute.
//  - Every winner's holdings are re-checked live; non-holders are skipped and
//    the next holder moves up.
//  - Each (round, place) is recorded before sending and each finished round is
//    marked paid/skipped, so re-running (or overlapping cron runs) never pays twice.

import fs from "node:fs";
import path from "node:path";
import { config, periodKey, previousPeriodKey, periodStart, PERIOD_RE } from "../server/config.js";
import { openDb, leaderboard } from "../server/db.js";
import { rpc, getTokenBalance, base58Encode, base58Decode } from "../server/solana.js";

// ---------------- args / env ----------------
const args = process.argv.slice(2);
const flag = (name) => args.includes(`--${name}`);
const opt = (name) => {
  const i = args.indexOf(`--${name}`);
  return i !== -1 ? args[i + 1] : undefined;
};

const EXECUTE = flag("execute");
const CLAIM = flag("claim");
const AUTO = flag("auto");
const env = process.env;
const ASSET = (env.PAYOUT_ASSET || "SOL").trim(); // "SOL" or an SPL mint address
const POT_FIXED = opt("pot") || env.PAYOUT_POT; // per round, UI units, e.g. "0.1"
const POT_PERCENT = Number(env.PAYOUT_POT_PERCENT || 0); // % of payout wallet balance, per round
const MIN_POT = Number(env.PAYOUT_MIN_POT || 0); // skip rounds whose pot is smaller than this
const MIN_PLAYERS = Math.max(1, Number(env.PAYOUT_MIN_PLAYERS || 1)); // eligible players needed for a round to pay
const SOL_RESERVE = Number(env.SOL_RESERVE || 0.05); // SOL kept for fees / rent
const GRACE_MS = Number(env.PAYOUT_GRACE_SECONDS || 60) * 1000; // wait after the hour closes
const LOOKBACK_HOURS = Number(env.PAYOUT_LOOKBACK_HOURS || 24); // --auto catches up this far back
const splits = config.prizeSplits;

function die(msg) {
  console.error(`\n✖ ${msg}\n`);
  process.exit(1);
}

if (splits.reduce((a, b) => a + b, 0) > 100) die("PAYOUT_SPLITS add up to more than 100");
if (!env.PAYOUT_KEYPAIR && !env.PAYOUT_SECRET_KEY)
  die("Set PAYOUT_SECRET_KEY (the payout wallet's private key, as exported from Phantom) or PAYOUT_KEYPAIR (path to a keypair JSON file)");
if (!POT_FIXED && !POT_PERCENT) die("Set PAYOUT_POT (fixed per round) or PAYOUT_POT_PERCENT (share of wallet balance per round)");
if (POT_PERCENT > 25) die("PAYOUT_POT_PERCENT above 25 would drain the wallet within a few hours — use a smaller % or PAYOUT_POT");
if (EXECUTE && config.skipHolderCheck) die("DEV_SKIP_HOLDER_CHECK is on — refusing to send real payouts");

// Accepts a Phantom/Solflare "export private key" string (base58) or a
// solana-keygen JSON array, either inline or from a file.
function loadSecret() {
  const rawText = (env.PAYOUT_SECRET_KEY || fs.readFileSync(env.PAYOUT_KEYPAIR, "utf8")).trim();
  if (rawText.startsWith("[")) return Uint8Array.from(JSON.parse(rawText));
  const b = base58Decode(rawText);
  return b ? Uint8Array.from(b) : new Uint8Array();
}
const secret = loadSecret();
if (secret.length !== 64) die("The payout private key doesn't look right — paste the full key exported from your wallet");
const payerAddress = base58Encode(secret.slice(32));

// ---------------- lock: never let two runs overlap ----------------
const lockFile = path.join(path.dirname(config.dbPath), "payout.lock");
if (EXECUTE) {
  fs.mkdirSync(path.dirname(lockFile), { recursive: true });
  try {
    if (fs.existsSync(lockFile) && Date.now() - fs.statSync(lockFile).mtimeMs > 30 * 60_000) fs.unlinkSync(lockFile); // stale
    fs.writeFileSync(lockFile, String(process.pid), { flag: "wx" });
  } catch {
    die(`Another payout run is in progress (${lockFile}). If it crashed, delete the file.`);
  }
  const release = () => { try { fs.unlinkSync(lockFile); } catch {} };
  process.on("exit", release);
  process.on("SIGINT", () => process.exit(130));
  process.on("SIGTERM", () => process.exit(143));
}

// ---------------- helpers ----------------
const toRaw = (ui, decimals) => {
  const [whole, frac = ""] = String(ui).split(".");
  return BigInt(whole || "0") * 10n ** BigInt(decimals) + BigInt((frac + "0".repeat(decimals)).slice(0, decimals) || "0");
};
const toUi = (raw, decimals) => {
  const s = raw.toString().padStart(decimals + 1, "0");
  const out = decimals ? `${s.slice(0, s.length - decimals)}.${s.slice(-decimals)}`.replace(/\.?0+$/, "") : s;
  return out || "0";
};

async function assetInfo() {
  if (ASSET === "SOL") return { label: "SOL", decimals: 9, programId: null };
  const info = await rpc(config.rpcUrl, "getAccountInfo", [ASSET, { encoding: "jsonParsed" }]);
  if (!info.value) die(`PAYOUT_ASSET mint ${ASSET} not found`);
  return { label: env.PAYOUT_ASSET_LABEL || ASSET.slice(0, 4) + "…", decimals: info.value.data.parsed.info.decimals, programId: info.value.owner };
}

async function availableRaw() {
  if (ASSET === "SOL") {
    const lamports = BigInt((await rpc(config.rpcUrl, "getBalance", [payerAddress])).value);
    const reserve = toRaw(SOL_RESERVE, 9);
    return lamports > reserve ? lamports - reserve : 0n;
  }
  return (await getTokenBalance(config.rpcUrl, payerAddress, ASSET)).raw;
}

// ---------------- StonkFun creator-fee claim (optional) ----------------
async function claimStonkfunFees(signTx) {
  if (!config.tokenMint) die("TOKEN_MINT not set");
  const base = "https://www.stonkfun.xyz/api/public/v1";
  const fees = await (await fetch(`${base}/tokens/${config.tokenMint}/fees`)).json();
  const claimable = fees?.data?.claimable?.quote?.amountTokens ?? 0;
  if (fees?.data?.reason) console.log(`StonkFun: ${fees.data.reason}`);
  if (!claimable) {
    console.log("No claimable creator fees (LaunchLab launches forward the creator share to your wallet automatically).");
    return;
  }
  console.log(`Claimable creator fees: ${claimable} ${fees.data.claimable.quote.symbol}`);
  if (!EXECUTE) return console.log("(dry run — not claiming)");
  const post = (p, body) =>
    fetch(`${base}/tokens/${config.tokenMint}${p}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    }).then((r) => r.json());
  const prep = await post("/fees/claim/prepare", { creatorWallet: payerAddress });
  if (!prep?.data?.transaction) return console.error(`Claim prepare failed: ${JSON.stringify(prep)} — continuing without claiming`);
  const signedTransaction = await signTx(prep.data.transaction);
  const sub = await post("/fees/claim/submit", { creatorWallet: payerAddress, intentId: prep.data.intentId, signedTransaction });
  if (!sub?.data?.signature) return console.error(`Claim submit failed: ${JSON.stringify(sub)} — continuing without claiming`);
  console.log(`✔ Claimed fees: ${sub.data.signature}`);
  await new Promise((r) => setTimeout(r, 8000)); // let balances settle
}

// ---------------- setup ----------------
const db = openDb(config.dbPath);
const roundDone = db.prepare("SELECT status FROM rounds WHERE period=? AND status IN ('paid','skipped')");
const setRound = db.prepare(
  "INSERT INTO rounds (period, status, note, updated_at) VALUES (?,?,?,?) ON CONFLICT(period) DO UPDATE SET status=excluded.status, note=excluded.note, updated_at=excluded.updated_at"
);
const getRow = db.prepare("SELECT * FROM payouts WHERE period=? AND rank=?");
const insertRow = db.prepare(
  "INSERT INTO payouts (period, rank, wallet, amount_raw, amount_ui, asset, asset_label, status, created_at) VALUES (?,?,?,?,?,?,?,'pending',?)"
);
const markRow = db.prepare("UPDATE payouts SET status=?, signature=? WHERE period=? AND rank=?");
const deleteRow = db.prepare("DELETE FROM payouts WHERE period=? AND rank=?");

// Solana libs load only when something is actually sent/claimed.
let web3, spl, payer, connection;
async function ensureWeb3() {
  if (web3) return;
  try {
    web3 = await import("@solana/web3.js");
    spl = await import("@solana/spl-token");
  } catch {
    die("Run `npm install` first — sending needs @solana/web3.js and @solana/spl-token");
  }
  payer = web3.Keypair.fromSecretKey(secret);
  connection = new web3.Connection(config.rpcUrl, "confirmed");
}

const finished = (p) => Date.now() - periodStart(p).getTime() >= 3600_000 + GRACE_MS;

// Which rounds to process
let rounds;
if (AUTO) {
  const since = periodKey(new Date(Date.now() - LOOKBACK_HOURS * 3600_000));
  rounds = db
    .prepare("SELECT DISTINCT period FROM scores WHERE period >= ? AND period < ? ORDER BY period")
    .all(since, periodKey())
    .map((r) => r.period)
    .filter((p) => finished(p) && !roundDone.get(p));
} else {
  const p = opt("period") || previousPeriodKey();
  if (!PERIOD_RE.test(p)) die(`Bad --period "${p}" (expected UTC hour like 2026-09-28T14)`);
  if (!finished(p)) die(`Round ${p} hasn't finished yet (plus ${GRACE_MS / 1000}s grace).`);
  rounds = [p];
}

console.log(`\nPayer ${payerAddress} · asset ${ASSET} · ${EXECUTE ? "EXECUTE" : "DRY RUN"} · ${rounds.length} round(s) to process`);
if (!rounds.length) {
  console.log("Nothing to pay.\n");
  process.exit(0);
}

if (CLAIM) {
  if (EXECUTE) await ensureWeb3();
  await claimStonkfunFees(async (b64) => {
    const tx = web3.VersionedTransaction.deserialize(Buffer.from(b64, "base64"));
    tx.sign([payer]);
    return Buffer.from(tx.serialize()).toString("base64");
  });
}

const asset = await assetInfo();

// ---------------- per-round payout ----------------
async function payRound(period) {
  console.log(`\n━━ Round ${period}:00 UTC ━━`);
  const done = roundDone.get(period);
  if (done) return console.log(`Already ${done.status}.`);

  const skip = (note) => {
    console.log(`Skipped: ${note}`);
    if (EXECUTE) setRound.run(period, "skipped", note, Date.now());
  };

  // 1. winners: walk the board, keep the first N wallets that still hold
  const board = leaderboard(db, period, 500);
  if (!board.length) return skip("no scores");
  const winners = [];
  for (const entry of board) {
    if (winners.length >= splits.length) break;
    let ok = true, bal = null;
    if (!config.skipHolderCheck) {
      bal = (await getTokenBalance(config.rpcUrl, entry.wallet, config.tokenMint)).ui;
      ok = bal >= config.minHold && bal > 0;
    }
    console.log(`  board #${entry.rank}  ${entry.wallet}  score ${entry.score}  ${ok ? "✔ holder" : `✖ skipped (holds ${bal})`}`);
    if (ok) winners.push(entry);
  }
  const eligiblePlayers = winners.length;
  if (eligiblePlayers < MIN_PLAYERS) return skip(`only ${eligiblePlayers} eligible player(s), need ${MIN_PLAYERS}`);

  // 2. pot (percent mode re-reads the balance each round, after earlier rounds' sends)
  let potRaw = POT_FIXED ? toRaw(POT_FIXED, asset.decimals) : ((await availableRaw()) * BigInt(Math.round(POT_PERCENT * 100))) / 10000n;
  if (potRaw <= 0n) return skip("pot is empty");
  if (MIN_POT && potRaw < toRaw(MIN_POT, asset.decimals)) return skip(`pot ${toUi(potRaw, asset.decimals)} below PAYOUT_MIN_POT ${MIN_POT}`);

  const plan = winners.map((w, i) => {
    const amountRaw = (potRaw * BigInt(Math.round(splits[i] * 100))) / 10000n;
    return { place: i + 1, wallet: w.wallet, score: w.score, amountRaw, amountUi: toUi(amountRaw, asset.decimals) };
  });
  console.log(`Pot: ${toUi(potRaw, asset.decimals)} ${asset.label}`);
  console.table(plan.map((p) => ({ place: p.place, wallet: p.wallet, score: p.score, amount: `${p.amountUi} ${asset.label}` })));
  if (!EXECUTE) return;

  // 3. send
  const total = plan.reduce((a, p) => a + p.amountRaw, 0n);
  const available = await availableRaw();
  if (total > available) {
    // Leave the round unmarked so the next hourly run retries it once topped up.
    return console.error(`✖ Payout wallet only has ${toUi(available, asset.decimals)} ${asset.label} available, need ${toUi(total, asset.decimals)} — will retry next run`);
  }

  await ensureWeb3();
  let allSent = true;
  for (const p of plan) {
    const existing = getRow.get(period, p.place);
    if (existing?.status === "sent") { console.log(`#${p.place} already paid (${existing.signature})`); continue; }
    if (existing?.status === "pending")
      die(`${period} #${p.place} has a 'pending' record — an earlier run may have sent it. Check the payer's history on an explorer, then set that row to 'sent' or delete it.`);
    if (existing) deleteRow.run(period, p.place); // failed → retry
    insertRow.run(period, p.place, p.wallet, p.amountRaw.toString(), p.amountUi, ASSET, asset.label, Date.now());

    try {
      const to = new web3.PublicKey(p.wallet);
      const tx = new web3.Transaction();
      if (ASSET === "SOL") {
        tx.add(web3.SystemProgram.transfer({ fromPubkey: payer.publicKey, toPubkey: to, lamports: p.amountRaw }));
      } else {
        const mint = new web3.PublicKey(ASSET);
        const programId = new web3.PublicKey(asset.programId);
        const fromAta = spl.getAssociatedTokenAddressSync(mint, payer.publicKey, false, programId);
        const toAta = spl.getAssociatedTokenAddressSync(mint, to, true, programId);
        tx.add(spl.createAssociatedTokenAccountIdempotentInstruction(payer.publicKey, toAta, to, mint, programId));
        tx.add(spl.createTransferCheckedInstruction(fromAta, mint, toAta, payer.publicKey, p.amountRaw, asset.decimals, [], programId));
      }
      const sig = await web3.sendAndConfirmTransaction(connection, tx, [payer], { commitment: "confirmed" });
      markRow.run("sent", sig, period, p.place);
      console.log(`✔ #${p.place} ${p.wallet}  ${p.amountUi} ${asset.label}  ${sig}`);
    } catch (e) {
      allSent = false;
      // Unknown outcome if it timed out after broadcast — leave 'pending' for a manual check.
      const unknown = /timeout|expired|not confirmed/i.test(e.message);
      if (!unknown) markRow.run("failed", null, period, p.place);
      console.error(`✖ #${p.place} ${p.wallet}: ${e.message}${unknown ? "  (left 'pending' — verify on an explorer)" : ""}`);
    }
  }
  setRound.run(period, allSent ? "paid" : "partial", null, Date.now());
}

for (const period of rounds) await payRound(period);
console.log(EXECUTE ? "\nDone.\n" : "\nDry run only. Add --execute to send.\n");
