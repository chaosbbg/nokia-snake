# How to put Snake on the internet (no coding needed)

Think of it like this:
- **GitHub** is a folder in the cloud where your game's files live.
- **Railway** is a computer in the cloud that runs your game 24/7 and gives it a web address.
- **The volume** is Railway's hard drive, where the leaderboard is saved.

You'll only use websites and copy-paste. It takes about 20–30 minutes.

---

## Step 1: Put the files on GitHub
1. Make a free account at **github.com**.
2. Click **+** (top right) and choose **New repository**. Name it `nokia-snake`, select **Private**, then click **Create repository**.
3. On the next page, click **"uploading an existing file"**.
4. Unzip `nokia-snake.zip` on your computer. Open the `nokia-snake` folder, select **everything inside it**, and drag it onto the GitHub page.
5. Click **Commit changes**.

## Step 2: Get a Solana connection (RPC)
The site needs to ask the Solana network "how many tokens does this wallet hold?". The free public connection gets overloaded, so get your own:
1. Make a free account at **helius.dev**.
2. Copy your **Mainnet RPC URL**. It looks like `https://mainnet.helius-rpc.com/?api-key=...`

## Step 3: Create the prize wallet
Use a **brand-new wallet** just for prizes. Never use your main wallet.
1. In Phantom: tap your account name, then **Add / Connect wallet**, then **Create new account**.
2. Open that account's settings, choose **Show private key**, and copy it. Keep it secret: anyone who has it can take the money in that wallet.
3. Send it a small amount of SOL. Keep only about a day's worth of prizes plus roughly 0.05 SOL for fees in it.

## Step 4: Launch on Railway
1. Go to **railway.com** and sign in with your GitHub account. Choose the Hobby plan (the paid plan is needed for saved storage).
2. Click **New Project**, then **Deploy from GitHub repo**, and pick `nokia-snake`.
   Railway sees it's a Node app and starts it automatically.

## Step 5: Give it a hard drive (so scores aren't wiped)
1. On the project screen, **right-click the empty area** (or press Ctrl/Cmd + K), choose **Volume**, and attach it to your snake service.
2. Set the **mount path** to exactly `/app/data`

## Step 6: Fill in the settings
Click your service, open the **Variables** tab, choose **Raw Editor**, and paste the block below with your own values filled in:

```
NODE_ENV=production
TRUST_PROXY=true
SESSION_SECRET=type-any-long-random-gibberish-at-least-32-characters-long
SOLANA_RPC_URL=paste-your-helius-url
TOKEN_MINT=your-token-address-from-stonkfun
TOKEN_SYMBOL=SNAKE
MIN_HOLD=100000
STONKFUN_URL=paste-your-token-page-link-on-stonkfun
PAYOUT_SECRET_KEY=paste-the-prize-wallet-private-key
PAYOUT_ASSET=SOL
PAYOUT_POT=0.001
PAYOUT_SPLITS=50,30,20
PAYOUT_MIN_PLAYERS=2
AUTO_PAYOUT=true
```

Click **Update**. Railway restarts the game with these settings.

> `PAYOUT_POT=0.001` is a tiny test amount per hour. Once you've watched a payout work, raise it (for example `0.05`).

## Step 7: Get your web address
Open **Settings**, go to **Networking**, and click **Generate Domain**. You'll get a link like `nokia-snake-production.up.railway.app`. That's your game.
(Own a domain? Use **Custom Domain** on the same screen and follow the instructions it shows.)

## Step 8: Check it works
- Open the link and play a practice game.
- Connect a wallet that holds your token. The Mode badge should turn green and say **Ranked**.
- At about **2 minutes past the hour**, open Railway's **Logs** tab. You'll see lines starting with `[payout]`. On the site, the **Recent payouts** box fills in, and each payout links to Solscan.

---

## Everyday stuff
- **Change a setting** (pot size, minimum hold): edit it in the Variables tab. The game restarts by itself.
- **Change the code**: edit the file on GitHub and commit. Railway updates the site automatically.
- **Pause payouts**: set `AUTO_PAYOUT=false`.
- **Top up prizes**: send SOL to the prize wallet.

## Testing before your token exists
Use these variables instead. Anyone can play ranked, and payouts are switched off:
```
NODE_ENV=development
DEV_SKIP_HOLDER_CHECK=true
AUTO_PAYOUT=false
```
Switch back to the real list before you announce the game.

## If something goes wrong
- **Site shows "Could not reach the game server"**: open **Logs**. A line starting with `Config errors` tells you which variable is missing.
- **Payout log says "Payout wallet only has …"**: the prize wallet is out of SOL. Top it up and it pays the missed hours on the next run.
- **Payout log mentions a 'pending' record**: a transfer may or may not have gone through. Look up the prize wallet on solscan.io before doing anything else.
