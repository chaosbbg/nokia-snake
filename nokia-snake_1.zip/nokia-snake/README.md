# Nokia Snake — holder-gated leaderboard with hourly payouts

A Nokia 3310–style Snake game for a StonkFun (Solana) token. Players who hold your token play ranked games, and the top of the leaderboard gets paid **every hour**.

- **Game:** 84×48 pixel LCD, keypad, keyboard, and swipe controls. Anyone can play practice games.
- **Ranked play:** the player connects Phantom, Solflare or Backpack and signs a free message (no transaction). The server checks they hold at least `MIN_HOLD` of your token.
- **Anti-cheat:** each ranked game gets a seed from the server. The browser sends back the list of turns it made, and the server replays the whole game move by move with the same engine (`shared/engine.js`). Faked scores, illegal moves, games finished faster than possible, reused sessions and parallel games are all rejected.
- **Hourly rounds:** each UTC clock hour is its own round with a fresh board. The site shows a live countdown and a feed of recent payouts linked to Solscan, so players can see that winners really get paid.
- **Payouts:** `scripts/payout.js` runs from cron every hour. It checks each winner's balance again at payout time and skips anyone who sold. It pays the top N in SOL or any SPL token. It is a dry run by default and records every payout so nobody gets paid twice.

The server has no npm dependencies. It uses Node's built-in `http`, `sqlite` and `crypto` modules. Only the payout script needs `@solana/web3.js` and `@solana/spl-token`.

## Quick start (local)

```bash
# Node 22.5+ required
npm install
cp .env.example .env
# edit .env: SESSION_SECRET, TOKEN_MINT, TOKEN_SYMBOL, MIN_HOLD, STONKFUN_URL
npm start               # http://localhost:3000
npm test                # engine + API + anti-cheat tests
```

To try ranked mode before your token exists, set `DEV_SKIP_HOLDER_CHECK=true` and `NODE_ENV=development`. The server won't start with that combination in production.

## Launch checklist

1. **Launch the token on StonkFun** (stonkfun.xyz/launch). Copy the mint address into `TOKEN_MINT` and paste your token page URL into `STONKFUN_URL`.
2. **Get a paid RPC.** Helius, QuickNode or Triton all work. The public mainnet RPC will rate-limit holder checks once real players show up.
3. **Deploy.** Any Node host with a persistent disk will do, such as Railway, Render (with a disk), Fly.io or a VPS. Keep `data/` on the persistent disk. Set `TRUST_PROXY=true` if the host puts a proxy in front of the app.
4. **Create a separate payout wallet.** Run `solana-keygen new -o payout-wallet.json`, fund it and point `PAYOUT_KEYPAIR` at it. Keep about a day's worth of hourly pots plus fees in it.
5. **Schedule the payout every hour**, a couple of minutes after the hour:
   ```bash
   npm run payout -- --auto            # dry run first: shows every unpaid round + amounts
   ```
   When the dry run looks right, add this line with `crontab -e` on your server:
   ```
   2 * * * * cd /path/to/nokia-snake && npm run payout -- --auto --execute >> data/payout.log 2>&1
   ```
   On Railway or Render, create a cron job service with schedule `2 * * * *` and command `npm run payout -- --auto --execute`. It must use the same disk or database as the web server.

   `--auto` pays every finished round from the last 24 hours that hasn't been paid or skipped yet, so a missed run or a short outage catches up on its own. A lock file stops two runs from overlapping.

   Manual options: `--period 2026-09-28T14` pays one specific hour (UTC), `--pot 0.1` overrides the pot, and `--claim` claims StonkFun creator fees first.

## Hourly settings (`.env`)

| Setting | What it does |
|---|---|
| `PAYOUT_POT` | Fixed pot **per hour**, e.g. `0.05` SOL is 1.2 SOL/day |
| `PAYOUT_POT_PERCENT` | Or a % of the payout wallet per hour. Capped at 25; 5% hourly leaves about 30% of an unrefilled wallet after a day |
| `PAYOUT_MIN_PLAYERS` | Skip hours with fewer distinct holders (default in template: 2). Stops one person farming quiet hours alone |
| `PAYOUT_MIN_POT` | Skip hours where the pot would be dust |
| `PAYOUT_GRACE_SECONDS` | Wait after the hour closes before paying (default 60) |

Unused prize shares stay in the wallet, for example the #3 share when only two people played. Each transfer costs about 0.000005 SOL. Paying in an SPL token costs about 0.002 SOL extra the first time a winner needs a token account.

## Funding the pot

StonkFun sends creator fees to the creator wallet. According to StonkFun's API docs, current LaunchLab launches forward the creator share automatically. Older launches need a claim through `POST /tokens/{mint}/fees/claim/prepare` and `/submit`, which `--claim` does for you. `--claim` only works if the payout wallet is the creator wallet that holds the Fee Key NFT.

You can set the pot in two ways:

- `PAYOUT_POT`: a fixed amount per hour.
- `PAYOUT_POT_PERCENT`: a share of the payout wallet's balance each hour.

`PAYOUT_ASSET=SOL` pays in SOL. You can also set it to any SPL mint, such as your quote asset. Token-2022 mints are supported. If the token charges a transfer tax, winners receive the amount minus that tax.

## How scoring works

- 10 points per food. The snake starts at 170 ms per move and gets 4 ms faster per food, down to 70 ms.
- Each wallet's best score in the hour counts. If two wallets tie, the one that reached the score first ranks higher.
- A game counts toward the hour in which it **ends**. A run that starts at 14:58 and ends at 15:03 counts for the 15:00 round.

## Limits to be honest about

- The replay check stops fake scores. It can't stop a **bot that actually plays the game** in real time. If prizes get big, add a per-wallet game cap, a minimum wallet age or holding time, and review top runs by hand (the `scores` table stores each run's ticks and duration).
- Hourly rounds pay out often, which makes botting more attractive than weekly rounds would. Keep `PAYOUT_MIN_PLAYERS` at 2 or more and keep the hourly pot modest.
- The holder check runs when a game starts and again at payout. A player could borrow tokens for a single game, but they still need to hold at payout to get paid.
- Rules around paying crypto prizes differ by country. Check what applies to you before you advertise rewards.

## Layout

```
shared/engine.js    deterministic game engine (browser + server)
server/index.js     HTTP API + static files
server/db.js        SQLite schema + leaderboard query
server/solana.js    base58, ed25519 sign-in, holder balance via RPC
public/             phone UI (index.html, style.css, game.js)
scripts/payout.js   hourly payouts (cron)
test/               node:test suite
```
